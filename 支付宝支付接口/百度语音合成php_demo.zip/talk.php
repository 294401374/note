<?php
header("Content-Type:audio/mp3");
//接收要读的文字
$word = strip_tags($_GET['word']);
$arr = array();
$str1 = '';
strtoarray($word);


//配置
$apikey = "aHxuGTQQT7M7OjUgS51uR21n";
$secretkey = "a3045db5f3c240f7ad211f4692b754b0";

//获取token
$url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=".$apikey."&client_secret=".$secretkey;
$response = json_decode(get_contents($url),true);
$token = $response['access_token'];
//var_dump($token);


foreach($arr as $v){
	//文件
	//$file = "yuyin.txt";
	//$audio = file_get_contents($file);

	//调用合成接口
	$url2 = "http://tsn.baidu.com/text2audio?";
	$setarr = array(
		"tex"	=> $v,
		"lan"	=> "zh",
		"tok"	=> $token,
		"ctp"	=> 1,
		"cuid"	=> "‎D0-53-49-6E-2E-4D",
		"spd"	=> 5,//语速0-9
		//"pit"	=> 5,//语调0-9
		//"vol"	=> 5,//音量0-9
		"per"	=> 3,//发声人0女，1男，3为情感合成-度逍遥，4为情感合成-度丫丫

	);
	$str = http_build_query($setarr);
	//var_dump($url2.$str);
	$str1 .= get_contents($url2.$str);
}

echo $str1;


function get_contents($url){
	$ch = curl_init($url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);//允许请求的内容以文件流的形式返回
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);//禁用https传输
	curl_setopt($ch,CURLOPT_URL,$url);//设置要请求的URL地址
	$str = curl_exec($ch);//执行url
	curl_close($ch);
	return $str;
}

function sysSubStr($String,$Length,$Append = false){
	if (strlen($String) <= $Length ){
		return $String;
	}else{
		$I = 0;
		while ($I < $Length)
		{
			$StringTMP = substr($String,$I,1);
			if ( ord($StringTMP) >=224 )
			{
				$StringTMP = substr($String,$I,3);
				$I = $I + 3;
			}
			elseif( ord($StringTMP) >=192 )
			{
				$StringTMP = substr($String,$I,2);
				$I = $I + 2;
			}
			else
			{
				$I = $I + 1;
			}
			$StringLast[] = $StringTMP;
		}
		$StringLast = implode("",$StringLast);
		if($Append)
		{
			$StringLast .= "...";
		}
		return $StringLast;
	}
}

function strtoarray($word){
	global $arr;
	$word1 = sysSubStr($word,"1024");
	$word2 = str_replace($word1,'',$word);
	$arr[] = $word1;
	if($word2){
		strtoarray($word2);
	}
}

?>
