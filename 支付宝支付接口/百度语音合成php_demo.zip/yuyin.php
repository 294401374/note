<?php
header("Content-Type:audio/mp3");
//配置
$apikey = "aHxuGTQQT7M7OjUgS51uR21n";
$secretkey = "a3045db5f3c240f7ad211f4692b754b0";

//获取token
$url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=".$apikey."&client_secret=".$secretkey;
$response = json_decode(get_contents($url),true);
$token = $response['access_token'];
//var_dump($token);

//文件
$file = "yuyin.txt";
$audio = file_get_contents($file);

//调用合成接口
$url2 = "http://tsn.baidu.com/text2audio?";
$setarr = array(
	"tex"	=> $audio,
	"lan"	=> "zh",
	"tok"	=> $token,
	"ctp"	=> 1,
	"cuid"	=> "‎D0-53-49-6E-2E-4D",
	//"spd"	=> 9,//语速0-9
	//"pit"	=> 0,//语调0-9
	//"vol"	=> 5,//音量0-9
	//"per"	=> 1,//发声人0女，1男，3为情感合成-度逍遥，4为情感合成-度丫丫

);
$str = http_build_query($setarr);
//var_dump($url2.$str);
$res = get_contents($url2.$str);
echo $res;


function get_contents($url){
	$ch = curl_init($url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);//允许请求的内容以文件流的形式返回
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);//禁用https传输
	curl_setopt($ch,CURLOPT_URL,$url);//设置要请求的URL地址
	$str = curl_exec($ch);//执行url
	curl_close($ch);
	return $str;
}

