<?php
//首先检测是否支持curl
if (!extension_loaded("curl")) {   
trigger_error("对不起，请开启curl功能模块！", E_USER_ERROR);
}
//构造xml

$xmlData='<?xml version="1.0" encoding="UTF-8"?>
	<Application>
		<Process>
		<Scope>inst</Scope>
		</Process>
		<LoadOnStartup>true</LoadOnStartup>
		 <StreamManager>
	            <StorageDir>/</StorageDir>
	            <VirtualDirectory>
	                    <Streams>/;/opt/video_dest</Streams>
	            </VirtualDirectory>
	            <Live>
	                    <Queue>
	                            <AggregateMessages enabled="true">
	                                    <MaxAggMsgDuration>500</MaxAggMsgDuration>
	                            </AggregateMessages>
	                    </Queue>
	            </Live>
	    </StreamManager>
		<Client>
			<OutChunkSize>448</OutChunkSize>
		</Client>
		<ScriptEngine>
			<RuntimeSize>10240</RuntimeSize>
			<FileObject>
				<VirtualDirectory>fmsConfRoot;/opt/adobe/ams/conf/</VirtualDirectory>
				<VirtualDirectory>appLogs;/opt/adobe/ams/logs/</VirtualDirectory>
				<VirtualDirectory>appPath;/opt/adobe/ams/applications/dreamStreamCore/</VirtualDirectory>
				<VirtualDirectory>/;/opt/video_dest/</VirtualDirectory>
			</FileObject>
			<ApplicationObject>
				<config>
				   <allowInteriorLogin>1</allowInteriorLogin>
					<alarmPortal><![CDATA[http://115.29.150.217:888/cms_cloud/alarm/api_alarm.jsp|0]]></alarmPortal>
	                <statPortal><![CDATA[http://192.168.137.10:888/live/api/liveStreamCheck.jsp?id={CHANNEL}&name={CHANNELNAME}&type={TYPE}&des={DES}]]></statPortal>
				</config>
			</ApplicationObject>
		</ScriptEngine>
	</Application>';
// 初始化curl
$url = 'http://127.0.0.1:8080/xml/tst/demoxml.php';
$header[] = "Content-type: text/xml";//定义content-type为xml
$curl = curl_init($url);
// curl_setopt();
curl_setopt($curl, CURLOPT_URL,$url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
curl_setopt($curl, CURLOPT_POST,1);
curl_setopt($curl, CURLOPT_POSTFIELDS,$xmlData);
$response = curl_exec($curl);
if(curl_errno($curl)){
    print curl_error($curl);
    echo 'sssss';
}
curl_close($curl);
echo $response;