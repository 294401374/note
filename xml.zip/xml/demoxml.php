<?php
$xml = file_get_contents("php://input");
$data = simplexml_load_string($xml);
// print_r($data);
echo '<hr>';
$str = json_encode($data);
$str = json_decode($str,true);
print_r($str);
read($str);
function read($arr){	

		foreach ($arr as $k => $v) {
			 if(is_array($v)){
			 	read($v);
			 }else{
			 	echo $v.'<br>';
			 }
		}		
}


