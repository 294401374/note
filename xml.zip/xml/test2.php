<?php
//创建DOM对象
$dom = new DomDocument();
$dom->load('Application.xml');
$root = $dom->documentElement;
$aObj = $dom->getElementsByTagName("ApplicationObject");
function readChild($node){
	$children = $node->childNodes;
	foreach($children as $k => $a ){
		if($a->nodeType == XML_TEXT_NODE){
			echo $a->nodeValue.'<br/>';
		}else if($a->nodeType == XML_ELEMENT_NODE){
			readChild($a);
		}
	}	
}
echo '1、输出Application/ScriptEnginel/VirtualDirectory标签（第2个VirtualDirectory）的值
<br/>';
$FileObjects	   = $dom->getElementsByTagName('FileObject');
$FileObject	 	   = $FileObjects->item(0)->nodeValue;
// foreach ($FileObject as $key => $value) {
// 	$vs = $value->getElementsByTagName('VirtualDirectory');
// 	$v = $vs->item($key)->nodeValue;
// 	echo $v;
// }
$VirtualDirectorys = $dom->getElementsByTagName("VirtualDirectory");
$VirtualDirectory  = $VirtualDirectorys->item(2)->nodeValue;
echo $VirtualDirectory;


		

echo '2、输出Application/ApplicationObject下所有标签的值<br/>';
$configs     = $dom->getElementsByTagName("config");
$config 	 = $configs->item(0)->nodeValue;
$statPortals =$dom->getElementsByTagName("statPortal");
$statPortal  =$statPortals->item(0)->nodeValue;
$alarmPortals=$dom->getElementsByTagName("alarmPortal");
$alarmPortal = $alarmPortals->item(0)->nodeValue;
$allowInteriorLogins = $dom->getElementsByTagName("allowInteriorLogin");
$allowInteriorLogin  = $allowInteriorLogins->item(0)->nodeValue;
echo $config.'<br>'.$allowInteriorLogin.'<br>'.$alarmPortal.'<br>'.$statPortal;

